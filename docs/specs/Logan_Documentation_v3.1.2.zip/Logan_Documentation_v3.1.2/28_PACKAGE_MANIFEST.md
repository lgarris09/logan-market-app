# Logan Intelligence — Package Manifest
**Version:** 3.1.2
*Source: Architecture v1.3 FINAL (2026-07-31). Original: “source_material/28_PACKAGE_MANIFEST.md” (historical label).*
*Complete index of all documents in the v3.1.2 package.*

---

## Core Documents (00–28)

| # | File | Version | Source | Verification Status | Notes |
|---|------|---------|--------|--------------------|----|
| 00 | 00_MASTER_BRIEF.md | 3.1.2 | v3.1 base (updated) | VERIFIED | 7 domains, TriggerEvent framework, v3.1.2 changes |
| 01 | 01_PRODUCT_SPECIFICATION.md | 3.1.2 | v3.1 base (updated) | VERIFIED | Culture and Personal Finance domains added |
| 02 | 02_LOGAN_INTELLIGENCE_BRAIN.md | 3.1.2 | v3.1 base (updated) | VERIFIED | TriggerEvent as first-class pipeline object; Memory/Feedback/Learning async note |
| 03 | 03_MEMORY_ARCHITECTURE.md | 3.1.2 | v3.1 base (updated) | VERIFIED | TriggerEvent outcome performance branch added |
| 04 | 04_WORLD_MODEL.md | 3.1.2 | v3.1 base (updated) | VERIFIED | trigger_events array added to WorldModel entity |
| 05 | 05_SYSTEM_ARCHITECTURE.md | 3.1.2 | v3.1 base (updated) | VERIFIED | TriggerEvent registry in pipeline; 7 domain receptors |
| 06 | 06_LAYER_INTERFACE_SPECIFICATION.md | 3.0 | source_material/02_LAYER_INTERFACES.md | VERIFIED | Direct copy from v1.3 spec; ground truth |
| 07 | 07_DATA_CONTRACTS.md | 3.1.2 | v3.1 base (updated) | VERIFIED | TriggerEvent data contract added; CommunitySignal momentum_score; new card fields |
| 08 | 08_BUILD_ORDER.md | 3.1.2 | v3.1 base (updated) | VERIFIED | TriggerEvent registry step added; Culture and Personal Finance receptors |
| 09 | 09_READ_AND_SUGGEST.md | 3.1.2 | v3.1 base (updated) | VERIFIED | LOCKED label; sports betting deferred to V2; user controls section added |
| 10 | 10_OPPORTUNITY_ENGINE.md | 3.1.2 | v3.1 base (updated) | VERIFIED | action_window_opens/closes; Culture/Personal Finance decay modifiers; data contracts ref |
| 11 | 11_UI_PHILOSOPHY.md | 3.1.2 | v3.1 base (updated) | VERIFIED | Community momentum/edge glow LOCKED rule; 7 domain colors; card hierarchy updated |
| 12 | 12_VISUAL_LANGUAGE.md | 3.1.2 | v3.1 base (updated) | VERIFIED | Culture and Personal Finance domain colors; edge glow LOCKED rule; momentum_score |
| 13 | 13_BRANDING.md | 3.1.2 | v3.1 base (updated) | VERIFIED | Advisory voice rule; correction state tone; TBD app name reinforced |
| 14 | 14_ENGINEERING_STANDARDS.md | 3.1.2 | v3.1 base (updated) | VERIFIED | TriggerEvent registry section; 7 domain folder structure; PROVISIONAL status column |
| 15 | 15_DECISIONS.md | 3.1.2 | v3.1 base (updated) | VERIFIED | DECISION-015 (TriggerEvent framework); DECISION-016 (community momentum → edge glow) |
| 16 | 16_ROADMAP.md | 3.1.2 | v3.1 base (updated) | VERIFIED | TriggerEvent in Sprint 2A path; 7 domains; action_window fields in Phase 5 |
| 17 | 17_CLAUDE_ENGINEERING_GUIDE.md | 3.1.2 | v3.1 base (updated) | VERIFIED | LOCKED rules expanded to 12; TriggerEvent and community momentum coding rules |
| 18 | 18_SESSION_LOG.md | 3.1.2 | v3.1 base (updated) | VERIFIED | v3.1.2 session entry added at top |
| 19 | 19_FUTURE_IDEAS.md | 3.1.2 | v3.1 base (updated) | VERIFIED | ML trigger discovery; Trigger Code Performance Dashboard |
| 20 | 20_LOGAN_PRINCIPLES.md | 3.1.2 | v3.1 base (updated) | VERIFIED | Principle 13 added; Principles 3, 4, 11 expanded |
| 21 | 21_TRENDING_ENGAGEMENT.md | 3.1.2 | v3.1 base (updated) | VERIFIED | momentum_score (renamed); LOCKED edge glow rule |
| 22 | 22_OPPORTUNITY_CARD_SPEC.md | 3.1.2 | v3.1 base (updated) | VERIFIED | 80-char headline; new card fields; NOT RELEVANT and REMIND ME buttons |
| 23 | 23_CURRENT_IMPLEMENTATION_STATE.md | 3.1.2 | v3.1 base (updated) | VERIFIED | TriggerEvent row; 7 domains; Sprint 2A target updated |
| 24 | 24_API_SPECIFICATION.md | 3.1.2 | v3.1 base (updated) | VERIFIED | interaction_type enum; new card fields in response; momentum_score; TriggerEvents |
| 25 | 25_INTEGRATION_FEASIBILITY.md | 3.1.2 | v3.1 base (updated) | VERIFIED | Culture domain (Spotify, Apple Music, YouTube); Personal Finance (FRED, BLS, BEA) |
| 26 | 26_GOLDEN_TEST_SCENARIOS.md | 3.1.2 | v3.1 base (updated) | VERIFIED | 13 scenarios (was 11); TriggerEvent and Correction State scenarios added; 7 domains |
| 27 | 27_SECURITY_PRIVACY_COMPLIANCE.md | 3.1.2 | v3.1 base (updated) | VERIFIED | User controls section; opt-in; cross-domain association; account disconnect deletion |
| 28 | 28_PACKAGE_MANIFEST.md | 3.1.2 | v3.1 base (updated) | VERIFIED | This file; full v3.1.2 index |

---

## TriggerEvent Framework Files (NEW in v3.1.2)

| File | Version | Status | Notes |
|------|---------|--------|-------|
| TRIGGER_EVENT_FRAMEWORK.md | 3.1.2 | WRITTEN | TriggerEvent architecture, contract, lifecycle, and enforcement rules |
| TRIGGER_REGISTRY_GLOBAL.md | 3.1.2 | WRITTEN | Master index of all registered trigger codes across all domains |
| TRIGGER_REGISTRY_STOCKS.md | 3.1.2 | WRITTEN | Stocks domain trigger codes |
| TRIGGER_REGISTRY_SPORTS.md | 3.1.2 | WRITTEN | Sports domain trigger codes |
| TRIGGER_REGISTRY_PREDICTION_MARKETS.md | 3.1.2 | WRITTEN | Prediction Markets domain trigger codes |
| TRIGGER_REGISTRY_CRYPTO.md | 3.1.2 | WRITTEN | Crypto domain trigger codes |
| TRIGGER_REGISTRY_CULTURE.md | 3.1.2 | WRITTEN | Culture domain trigger codes |
| TRIGGER_REGISTRY_PERSONAL_FINANCE.md | 3.1.2 | WRITTEN | Personal Finance domain trigger codes |
| TRIGGER_SCORING_AND_CONFLICT_RULES.md | 3.1.2 | WRITTEN | How TriggerEvents affect scoring; conflict resolution |
| ENTITY_RESOLUTION.md | 3.1.2 | WRITTEN | Cross-domain entity identity resolution rules |
| NOTIFICATION_POLICY.md | 3.1.2 | WRITTEN | When Logan notifies; notification types; frequency rules |
| OUTCOME_EVALUATION.md | 3.1.2 | WRITTEN | How Logan evaluates whether an opportunity played out correctly |

---

## Supporting Files

| File | Version | Status | Notes |
|------|---------|--------|-------|
| DOCUMENTATION_CHANGELOG_v3.1.2.md | 3.1.2 | WRITTEN | Full v3.1 → v3.1.2 delta |
| DOCUMENTATION_REFERENCE_AUDIT.md | 3.1.2 | WRITTEN | Cross-reference check across all docs |
| source_material/ | 1.3 FINAL | PRESERVED | Original spec (2026-07-31); 10 files; ground truth for tech specs |

---

## Total

- **Core files:** 29 numbered documents (00–28)
- **TriggerEvent framework:** 12 new files
- **Supporting:** DOCUMENTATION_CHANGELOG + DOCUMENTATION_REFERENCE_AUDIT + source_material/ (10 files)
- **Total:** 55 files

---

## Files That Must Be Updated Regularly

| File | Update Trigger |
|------|--------------|
| `18_SESSION_LOG.md` | Every working session |
| `23_CURRENT_IMPLEMENTATION_STATE.md` | Every session that changes code |
| `15_DECISIONS.md` | When any decision is made or changes |
| `28_PACKAGE_MANIFEST.md` | When new files are added |
| `TRIGGER_REGISTRY_GLOBAL.md` | When any new trigger code is added to any domain registry |
| Domain trigger registries | When new trigger codes are added or existing codes are modified |

---

*Logan Intelligence Package Manifest — v3.1.2 | 2026-08-03*
*v3.1.2 changes: All 29 core document entries updated from v3.1 to v3.1.2 with change summaries. TriggerEvent Framework section added (12 new files). DOCUMENTATION_REFERENCE_AUDIT.md added to Supporting Files. Total count updated from 40 to 55. TRIGGER_REGISTRY_GLOBAL.md added to regularly-updated files list.*


## v3.1.2 Patch
All top-level documents are version-aligned to v3.1.2. Trigger framework and operational requirements supersede their v3.1.1 sections where conflicts exist.
