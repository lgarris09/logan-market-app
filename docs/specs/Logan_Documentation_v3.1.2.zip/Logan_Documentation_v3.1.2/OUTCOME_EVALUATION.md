# Logan Intelligence — Outcome Evaluation
**Version:** 3.1.2
*New in v3.1.2. No prior version.*

---

## Purpose

Outcome evaluation is how Logan learns whether its intelligence was correct. It is the feedback loop that connects a surfaced opportunity, through the user's experience, to Logan's future accuracy.

Without outcome evaluation, Logan has no way to improve. It would repeat the same reasoning patterns regardless of whether they produced accurate intelligence.

---

## When Outcome Evaluation Occurs

An opportunity enters the **Outcome** stage when:
1. The underlying event resolves (e.g., earnings are reported, a game is played, a contract expires)
2. The Action Window closes (if applicable)
3. The opportunity decays to inaction (no user interaction, signal fades)

After the Outcome stage, the opportunity enters the **Learning** stage, where outcome evaluation runs.

---

## What Is Being Evaluated

Outcome evaluation measures three things:

### 1. Hit Quality Accuracy

Was Logan's `hit_quality_score` correct given what actually happened?

```
hit_accuracy = 1.0 - abs(predicted_hit_quality - actual_outcome_quality)
```

**actual_outcome_quality** is determined by the domain-specific outcome evaluator:
- **Stocks:** Did the price move in the predicted direction? By approximately the implied magnitude?
- **Sports:** Did the game result match the signal direction (e.g., the underdog Logan identified won)?
- **Prediction Markets:** Did the contract resolve in the direction implied by Logan's analysis?
- **Culture:** Did the artist/content continue to gain momentum as predicted?
- **Personal Finance:** Did the macro event lead to the market/rate changes Logan's reasoning implied?

### 2. Thesis Accuracy

Was Logan's hypothesis — the stated reason the opportunity was worth attention — correct?

This is a qualitative evaluation driven by:
- Whether the stated `what_happened` triggers actually played out
- Whether the `why_now` timing was correct
- Whether `contradicting_evidence` Logan surfaced proved prescient (suggests good calibration)

For V1, thesis accuracy is logged but not automatically scored — it requires the Hypothesis Engine to compare outcome data against the original hypothesis. This is a V2 automation target.

### 3. TriggerEvent Predictive Accuracy

For each TriggerEvent code that fired for this opportunity: did that trigger code correlate with a positive outcome?

```
For each trigger_code in opportunity.trigger_events:
    outcome_per_trigger[trigger_code] += 1 win or loss
    running_accuracy[trigger_code] = wins / (wins + losses)
```

This produces per-code accuracy rates that feed the Learning System. Over time, trigger codes with low predictive accuracy are flagged for registry review.

---

## Outcome Sources

Logan uses these sources to determine outcomes:

| Domain | Primary Outcome Source | Fallback |
|--------|----------------------|----------|
| Stocks | Price data (Alpaca/Polygon) — compare to thesis direction | None |
| Sports | Game result from sports data provider | None |
| Prediction Markets | Contract resolution from Kalshi/Polymarket API | None |
| Culture | Chart position and stream data 7 days post-trigger | Social signal |
| Personal Finance | Market reaction data (rate changes, asset prices) 3 days post-announcement | BLS/Fed subsequent releases |

**V1 limitation:** Outcome sources require the Domain Receptor to still be running. If the receptor has been paused or the data provider is unavailable, outcome evaluation is deferred (not skipped — deferred until data is available).

---

## Outcome Evaluation Timeline

| Domain | Evaluation Wait Period | Rationale |
|--------|----------------------|-----------|
| Stocks (earnings) | 5 trading days | Enough time for initial market reaction to settle |
| Sports | 24 hours after game | Game is complete |
| Prediction Markets | At contract resolution | Contract resolves definitively |
| Culture | 7 days | Enough time for momentum signals to confirm or reverse |
| Personal Finance | 5 trading days | Market reaction to macro data |

---

## Outcome Object

```json
{
  "opportunity_id": "opp_abc123",
  "schema_version": "1.0",
  "evaluation_at": "2026-08-10T09:00:00Z",
  "outcome_source": "alpaca_price_data",
  "thesis_direction": "up",
  "actual_direction": "up",
  "thesis_magnitude_implied_pct": 8.0,
  "actual_magnitude_pct": 6.4,
  "hit_accuracy": 0.80,
  "thesis_correct": true,
  "trigger_outcomes": [
    {"trigger_code": "STOCK_EARNINGS_BEAT", "contributed_correctly": true},
    {"trigger_code": "STOCK_OPTIONS_FLOW_SURGE", "contributed_correctly": true}
  ],
  "contradicting_evidence_proved_significant": false,
  "user_acted": true,
  "user_feedback_type": "acted",
  "learning_system_received": true
}
```

---

## What Outcome Evaluation Feeds

Outcome results are passed to the Learning System, which updates:

1. **TriggerEvent performance metrics** — per-code accuracy rates in the Memory System
2. **Detector calibration** — were the detectors that fired for this opportunity well-calibrated?
3. **Domain analysis accuracy** — was the domain_analysis layer's hit_quality prediction correct?
4. **User prediction calibration** — if the user acted, was their action rewarded? This feeds user_value_score calibration.

The Learning System writes these updates asynchronously. The Opportunity Engine does not wait for learning before surfacing future opportunities — learning is a background process.

---

## V1 Automation Scope

In V1, the following aspects of outcome evaluation are automated:
- Outcome data collection from Domain Receptors (automated)
- Direction accuracy check (automated)
- TriggerEvent outcome logging (automated)
- Learning System signal write (automated)

The following are deferred to V2:
- Thesis accuracy scoring (requires NLP comparison of hypothesis vs. outcome text)
- Automated outcome detection for all edge cases (V2 extension point noted in `19_FUTURE_IDEAS.md`)
- Counterfactual scoring ("what would have happened if the user had acted?" — V2, extension point reserved)

---

## Non-Outcome Situations

Not every opportunity has a clean outcome:

| Situation | Treatment |
|-----------|-----------|
| Signal fades without event | Record as "inconclusive" — no hit/miss logged |
| User dismissed before event | Record dismissal; still evaluate outcome for Logan's accuracy tracking (not for user learning) |
| Data unavailable for outcome | Defer evaluation; do not fabricate outcome |
| Opportunity reversed (thesis changed) | Correction state is noted; evaluate the revised thesis, not the original |

---

*Logan Intelligence Outcome Evaluation — v3.1.2 | 2026-08-03*
*New in v3.1.2.*
